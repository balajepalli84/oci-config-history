import oci
import os
import datetime
import time
from dateutil import parser
from datetime import timezone

# Load OCI Configuration
Signer = oci.auth.signers.get_resource_principals_signer()  # Get Resource Principal Credentials
LOG_GROUP_OCID = os.getenv("LOG_GROUP_OCID", "Not Set")
LOG_OCID = os.getenv("LOG_OCID", "Not Set")
COMPARTMENT_ID=os.getenv("COMPARTMENT_ID", "Not Set")

# OCI Clients
search_client = oci.resource_search.ResourceSearchClient(config={}, signer=Signer)
logging_mgmt_client = oci.logging.LoggingManagementClient(config={}, signer=Signer)
logging_client = oci.loggingingestion.LoggingClient(config={}, signer=Signer)
kms_vault_client = oci.key_management.KmsVaultClient(config={}, signer=Signer)

def log_event(log_stream_id, message, start_time=None):
    current_time = datetime.datetime.utcnow().replace(tzinfo=datetime.timezone.utc)
    
    # Calculate runtime if start_time is provided
    runtime_info = ""
    if start_time:
        elapsed_seconds = (datetime.datetime.utcnow() - start_time).total_seconds()
        runtime_info = f"\nRuntime (seconds): {elapsed_seconds}"

    # Prepend timestamp and runtime to the message
    final_message = f"ExecutedTime: {current_time.isoformat()}Z{runtime_info}\n{message}"

    log_entry = oci.loggingingestion.models.PutLogsDetails(
        specversion="1.0",
        log_entry_batches=[
            oci.loggingingestion.models.LogEntryBatch(
                entries=[
                    oci.loggingingestion.models.LogEntry(
                        data=final_message,
                        id=str(current_time.timestamp()),
                        time=current_time
                    )
                ],
                source="KeyRotationChecker",
                type="CUSTOM",
                defaultlogentrytime=current_time,
                subject="KeyRotationCheck"
            )
        ]
    )

    logging_client.put_logs(log_stream_id, log_entry)



def get_key_version_creation_time(key_ocid, key_version_ocid, vault_id):
    vault_resp = kms_vault_client.get_vault(vault_id).data
    vault_management_endpoint = vault_resp.management_endpoint

    kms_mgmt_client = oci.key_management.KmsManagementClient(
        config={}, signer=Signer, service_endpoint=vault_management_endpoint
    )

    version = kms_mgmt_client.get_key_version(key_ocid, key_version_ocid).data
    return version.time_created


def check_key_rotation():
    six_months_ago = (datetime.datetime.utcnow() - datetime.timedelta(days=180)).replace(tzinfo=datetime.timezone.utc)

    response = search_client.search_resources(
        search_details=oci.resource_search.models.StructuredSearchDetails(
            query="query key resources return allAdditionalFields where lifecycleState = 'ENABLED'",
            type="Structured"
        )
    )

    log_group_id = LOG_GROUP_OCID 
    log_stream_id = LOG_OCID

    for item in response.data.items:
        key_ocid = item.identifier
        additional_details = item.additional_details

        current_key_version_ocid = additional_details.get("currentKeyVersion")
        vault_id = additional_details.get("vaultId")

        if not current_key_version_ocid or not vault_id:
            print(f"Missing currentKeyVersion or vaultId for key: {key_ocid}, skipping...")
            continue

        try:
            version_created_time = get_key_version_creation_time(
                key_ocid, current_key_version_ocid, vault_id
            )

            if version_created_time.tzinfo is None:
                version_created_time = version_created_time.replace(tzinfo=datetime.timezone.utc)

        except Exception as e:
            print(f"Error fetching version info for key: {key_ocid} - {str(e)}")
            continue

        if version_created_time < six_months_ago:
            message = (
                f"Key Rotation Alert:\n"
                f"Key OCID: {key_ocid}\n"
                f"Current Key Version: {current_key_version_ocid}\n"
                f"Compartment: {item.compartment_id}\n"
                f"Key Created: {item.time_created}\n"
                f"Current Key Version Created: {version_created_time}\n"
                f"Additional Details: {additional_details}"
            )
            log_event(log_stream_id, message)
            print(f"Logged rotation alert for key: {key_ocid}")
        else:
            print(f"Key {key_ocid} is compliant. Last rotation: {version_created_time}")


if __name__ == "__main__":
    check_key_rotation()
